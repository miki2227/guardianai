<img src="assets/icon.svg" width="64" height="64" alt="">

# GuardianAI

Experimental Jev-gated command execution with Linux kernel namespace isolation.
See [research scope and limitations](RESEARCH.md) before running untrusted code.

The expanded [research report](research/REPORT.md) includes a primary-source
[literature audit](research/LITERATURE.md), replicated real WSL2 executions, live
Jev judgments, evidence-damage ablations, and engineered two-agent channel controls.
Use [reproduction instructions](research/REPRODUCE.md) to inspect the raw traces
or run the study. The report preserves negative results and limits novelty claims.

Requires Python 3.10+, Linux (native or WSL2), Bubblewrap, and user namespaces.
Set `TYPESAFE_API_KEY` in the trusted supervisor environment. Never put credentials
in the task directory. Jev evaluates task text and command arguments remotely.

```sh
mkdir -p /tmp/guardian-input
output_dir=$(mktemp -d /tmp/guardian-output.XXXXXX)
python3 guardian.py --task 'Write /output/result.txt containing ok' \
  --workspace /tmp/guardian-input --output "$output_dir" -- \
  python3 -c "from pathlib import Path; Path('/output/result.txt').write_text('ok')"
python3 -m unittest discover -s tests -v
```

The CLI denies on Jev probability >= 0.2 or missing/invalid provider results.
This threshold has not been calibrated for deployment. The model is pinned to
`jev-1.14.0`. Inputs are mounted read-only at `/workspace`. Results go into a
separate, initially empty directory at `/output`; the command starts in `/output`.
Input and output directories must be disjoint, including resolved symlinks.
The isolated command can write `/output` and private `/tmp`,
read runtime libraries, and cannot use the host network or see host home directories.
Child processes inherit isolation. No kernel module is installed.

`python tests/live_pilot.py` runs six synthetic command descriptions against the
real Jev API and writes `evidence/live-pilot-output-boundary.json`; it executes no described commands.
Kernel tests execute bounded Python payloads with actual namespace isolation.
Windows skips those tests; run them inside Linux for containment evidence.

Earlier evidence records the initial fully writable workspace prototype. Those
reports remain historical; their runners use its earlier API. Current launch calls
require `output=` and the CLI requires `--output`.

`audit_session.py` adds strace-based kernel-origin evidence and a retrospective
task-rule/Jev audit. It requires a trusted evidence directory outside the agent's
mounts. This is user-space tracing of kernel syscalls; Jev inference remains remote.
