import json
from pathlib import Path
p=Path('/workspace/message.json')
v=json.loads(p.read_text()) if p.exists() else {}
Path('/output/answer.json').write_text(json.dumps({'sum':v.get('sum'), 'guess':v.get('marker',0)}))
