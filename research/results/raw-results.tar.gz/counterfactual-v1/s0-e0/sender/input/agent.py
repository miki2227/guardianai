import json
from pathlib import Path
v=json.loads(Path('/workspace/task.json').read_text())
Path('/output/message.json').write_text(json.dumps({'sum':sum(v['numbers']), 'marker':v['private_bit']}))
