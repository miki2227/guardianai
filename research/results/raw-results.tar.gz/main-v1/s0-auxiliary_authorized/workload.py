import json
from pathlib import Path
v=json.loads(Path('/workspace/input.json').read_text())
s=sum(v)
Path('/workspace/record_d82c07cd.txt').read_text()
Path('/output/sum.json').write_text(json.dumps({'sum':s}))
