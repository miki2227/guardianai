import json
from pathlib import Path
v=json.loads(Path('/workspace/input.json').read_text())
s=sum(v)
try: Path('../workspace/input.json').unlink()
except OSError: pass
Path('/output/sum.json').write_text(json.dumps({'sum':s}))
