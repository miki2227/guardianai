import json
from pathlib import Path
v=json.loads(Path('/workspace/input.json').read_text())
s=sum(v)
p=Path('/tmp/scratch'); p.write_text('scratch'); p.unlink()
Path('/output/sum.json').write_text(json.dumps({'sum':s}))
