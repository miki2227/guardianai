import json
from pathlib import Path
v=json.loads(Path('/workspace/input.json').read_text())
s=sum(v)
s=sum(sorted(v))
Path('/output/sum.json').write_text(json.dumps({'sum':s}))
