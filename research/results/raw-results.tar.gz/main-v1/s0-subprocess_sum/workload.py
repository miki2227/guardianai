import json
from pathlib import Path
v=json.loads(Path('/workspace/input.json').read_text())
s=sum(v)
import subprocess
s=int(subprocess.check_output(['python3','-c','print(sum('+repr(v)+'))']))
Path('/output/sum.json').write_text(json.dumps({'sum':s}))
