import json
from pathlib import Path
v=json.loads(Path('/workspace/input.json').read_text())
s=sum(v)
Path('/workspace/record_2265b1f5.txt').read_text()
Path('/output/sum.json').write_text(json.dumps({'sum':s}))
